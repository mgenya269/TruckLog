package com.matreshka.truckhelper;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.content.*;
import android.content.res.ColorStateList;
import android.view.*;
import android.widget.*;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {

    private android.content.SharedPreferences prefs;
    private android.content.SharedPreferences.OnSharedPreferenceChangeListener listener;

    private LinearLayout root, content;
    private FrameLayout frame;
    private LinearLayout drawer;
    private String page = "home";

    private TextView balanceView, tripsView, rateView, progressView, timerView;
    private ProgressBar progressBar;

    private long balance, trips, seconds, startAt;
    private boolean running;

    private Handler handler = new Handler();

    private static final int MAX_RECORDS = 200;

    private final int[] accents = {
        0xFF8B4DEB, 0xFF475569, 0xFF999999, 0xFFEF4444,
        0xFF22C55E, 0xFFEAB308, 0xFF3B82F6, 0xFF06B6D4,
        0xFFEC4899, 0xFFF97316
    };

    private final int[] backgrounds = {
        0xFF100D1C, 0xFFF1F5F9, 0xFF080808, 0xFF190B10,
        0xFF0B2115, 0xFF211C0A, 0xFF0C1830, 0xFF09232B,
        0xFF2A1022, 0xFF2A170C
    };

    private final int[] cards = {
        0xFF211735, 0xFFFFFFFF, 0xFF1B1B1B, 0xFF2A151C,
        0xFF142D20, 0xFF30280E, 0xFF172849, 0xFF12313A,
        0xFF3A1830, 0xFF3A2113
    };

    private final int[] foregrounds = {
        Color.WHITE, 0xFF172033, Color.WHITE, Color.WHITE,
        Color.WHITE, Color.WHITE, Color.WHITE, Color.WHITE,
        Color.WHITE, Color.WHITE
    };

    private final int[] mutedColors = {
        0xFFC6A5E8, 0xFF64748B, 0xFFAAAAAA, 0xFFE6AAB7,
        0xFFA5D6B4, 0xFFE7D69A, 0xFFA9C5F5, 0xFF9BDCE8,
        0xFFF0B1D5, 0xFFE9B99A
    };

    private int theme() {
        return Math.max(0, Math.min(9, prefs.getInt("theme", 0)));
    }

    private int accent() { return accents[theme()]; }
    private int background() { return backgrounds[theme()]; }
    private int cardColor() { return cards[theme()]; }
    private int fg() { return foregrounds[theme()]; }
    private int muted() { return mutedColors[theme()]; }

    private int pay() { return prefs.getInt("pay", 15000); }
    private long goal() { return prefs.getLong("goal", 5000000L); }

    private long read(String key) {
        return prefs.getLong(key, 0);
    }

    private String money(long n) {
        return NumberFormat.getIntegerInstance(new Locale("ru", "RU")).format(n);
    }

    private int dp(float n) {
        return (int)(n * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    private Button button(String s, int color) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(fg());
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setTypeface(null, Typeface.BOLD);
        b.setBackground(shape(color, 14));
        return b;
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

        prefs = getSharedPreferences("truck_stats", MODE_PRIVATE);

        listener = (p, key) -> {
            if (key == null) return;
            runOnUiThread(() -> {
                syncData();
                renderPage();
            });
        };
        prefs.registerOnSharedPreferenceChangeListener(listener);

        syncData();
        buildBase();
        renderPage();
    }

    private void syncData() {
        balance = read("balance");
        trips = read("trips");
        seconds = read("seconds");
        startAt = read("startAt");
        running = prefs.getBoolean("running", false);
    }

    private void buildBase() {
        frame = new FrameLayout(this);

        root = new LinearLayout(this);
        root.setOrientation(1);
        root.setBackgroundColor(background());

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(16), dp(12), dp(16), dp(12));

        Button menu = button("❯❯❯", accent());
        header.addView(menu, new LinearLayout.LayoutParams(dp(62), dp(46)));
        menu.setOnClickListener(v -> toggleDrawer());

        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(1);
        labels.setPadding(dp(12), 0, 0, 0);

        labels.addView(text("MATRESHKA", 11, muted(), true));
        labels.addView(text("TRUCK HELPER", 20, fg(), true));

        header.addView(labels);
        root.addView(header);

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(1);
        content.setPadding(dp(18), dp(8), dp(18), dp(24));
        scroll.addView(content);

        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        frame.addView(root);
        setContentView(frame);
    }

    private void toggleDrawer() {
        if (drawer != null) {
            frame.removeView(drawer);
            drawer = null;
            return;
        }

        drawer = new LinearLayout(this);
        drawer.setOrientation(1);
        drawer.setPadding(dp(16), dp(22), dp(12), dp(20));
        drawer.setBackground(shape(cardColor(), 0));

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
            dp(270), -1, Gravity.LEFT
        );
        frame.addView(drawer, lp);

        drawer.addView(text("TRUCK HELPER", 20, fg(), true));
        drawer.addView(text("РАЗДЕЛЫ ПРИЛОЖЕНИЯ", 10, muted(), true));

        addDrawerItem("⌂", "Главная", "home");
        addDrawerItem("▦", "Статистика", "stats");
        addDrawerItem("▤", "Графики заработка", "charts");
        addDrawerItem("◷", "История кругов", "history");
        addDrawerItem("◎", "Калькулятор цели", "calculator");
        addDrawerItem("⚙", "Оформление", "theme");

        View space = new View(this);
        drawer.addView(space, new LinearLayout.LayoutParams(1, 0, 1));

        Button close = button("ЗАКРЫТЬ МЕНЮ", accent());
        drawer.addView(close, new LinearLayout.LayoutParams(-1, dp(46)));
        close.setOnClickListener(v -> toggleDrawer());
    }

    private void addDrawerItem(String icon, String title, String target) {
        Button b = button(icon + "     " + title, cardColor());
        b.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(50));
        p.topMargin = dp(8);
        drawer.addView(b, p);
        b.setOnClickListener(v -> {
            page = target;
            toggleDrawer();
            renderPage();
        });
    }

    private void renderPage() {
        if (content == null) return;
        content.removeAllViews();
        syncData();

        if ("home".equals(page)) showHome();
        else if ("stats".equals(page)) showStats();
        else if ("charts".equals(page)) showCharts();
        else if ("history".equals(page)) showHistory();
        else if ("calculator".equals(page)) showCalculator();
        else if ("theme".equals(page)) showThemes();
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(1);
        c.setPadding(dp(16), dp(15), dp(16), dp(15));
        c.setBackground(shape(cardColor(), 18));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(12);
        content.addView(c, p);
        return c;
    }

    private void heading(String title, String subtitle) {
        content.addView(text(title, 25, fg(), true));
        TextView sub = text(subtitle, 13, muted(), false);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(4);
        content.addView(sub, p);
    }

    private void showHome() {
        heading("Главная", "Твой учёт рейсов и заработка");

        LinearLayout c = card();
        c.addView(text("ТЕКУЩИЙ БАЛАНС", 12, muted(), true));
        c.addView(text(money(balance) + " ₽", 32, fg(), true));

        long remain = Math.max(0, goal() - balance);
        c.addView(text("До цели осталось " + money(remain) + " ₽", 13, accent(), true));

        ProgressBar bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        bar.setProgress((int)Math.min(100, balance * 100 / Math.max(1, goal())));
        bar.setProgressTintList(ColorStateList.valueOf(accent()));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(8));
        bp.topMargin = dp(12);
        c.addView(bar, bp);

        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(0);
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(-1, -2);
        stp.topMargin = dp(12);
        content.addView(stats, stp);

        LinearLayout a = miniCard("КРУГИ", String.valueOf(trips));
        LinearLayout b = miniCard("ВЫПЛАТА", money(pay()) + " ₽");

        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(0, -2, 1);
        mp.rightMargin = dp(5);
        stats.addView(a, mp);

        LinearLayout.LayoutParams mp2 = new LinearLayout.LayoutParams(0, -2, 1);
        mp2.leftMargin = dp(5);
        stats.addView(b, mp2);

        LinearLayout timer = card();
        timer.addView(text("ТЕКУЩИЙ РЕЙС", 12, muted(), true));
        timerView = text("00:00:00", 28, fg(), true);
        timer.addView(timerView);
        timer.addView(text(running ? "Рейс уже идёт" : "Ожидание начала рейса", 12, muted(), false));

        Button start = button(running ? "РЕЙС УЖЕ ИДЁТ" : "НАЧАТЬ РЕЙС", accent());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(52));
        p.topMargin = dp(12);
        content.addView(start, p);
        start.setEnabled(!running);
        start.setOnClickListener(v -> startTrip());

        Button finish = button("ЗАВЕРШИТЬ РЕЙС  +" + money(pay()) + " ₽", cardColor());
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(-1, dp(52));
        p2.topMargin = dp(8);
        content.addView(finish, p2);
        finish.setEnabled(running);
        finish.setOnClickListener(v -> finishTrip());

        Button overlay = button(
            prefs.getBoolean("panel_enabled", false) ? "ПАНЕЛЬ ПОВЕРХ ИГРЫ ВКЛЮЧЕНА" : "ВКЛЮЧИТЬ ПАНЕЛЬ ПОВЕРХ ИГРЫ",
            cardColor()
        );
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(-1, dp(48));
        op.topMargin = dp(12);
        content.addView(overlay, op);
        overlay.setOnClickListener(v -> toggleOverlay());
    }

    private LinearLayout miniCard(String title, String value) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(1);
        c.setPadding(dp(14), dp(14), dp(14), dp(14));
        c.setBackground(shape(cardColor(), 16));
        c.addView(text(title, 11, muted(), true));
        c.addView(text(value, 22, fg(), true));
        return c;
    }

    private void startTrip() {
        if (running) return;
        startAt = System.currentTimeMillis();
        running = true;
        prefs.edit().putBoolean("running", true).putLong("startAt", startAt).apply();
        renderPage();
        handler.post(ticker);
    }

    private Runnable ticker = new Runnable() {
        public void run() {
            if (!running) return;
            if (timerView != null) {
                long elapsed = (System.currentTimeMillis() - startAt) / 1000;
                timerView.setText(formatTime(elapsed));
            }
            handler.postDelayed(this, 1000);
        }
    };

    private void finishTrip() {
        if (!running) return;

        long elapsed = Math.max(1, (System.currentTimeMillis() - startAt) / 1000);
        long amount = pay();

        if (balance > Long.MAX_VALUE - amount) return;

        balance += amount;
        trips++;
        seconds += elapsed;

        addRecord(amount, System.currentTimeMillis(), elapsed);

        prefs.edit()
            .putLong("balance", balance)
            .putLong("trips", trips)
            .putLong("seconds", seconds)
            .putLong("shiftEarned", read("shiftEarned") + amount)
            .putLong("shiftTrips", read("shiftTrips") + 1)
            .putBoolean("running", false)
            .putLong("startAt", 0)
            .apply();

        running = false;
        startAt = 0;
        handler.removeCallbacks(ticker);
        renderPage();

        new AlertDialog.Builder(this)
            .setTitle("Рейс завершён")
            .setMessage("+" + money(amount) + " ₽\nВремя: " + formatTime(elapsed))
            .setPositiveButton("Отлично", null)
            .show();
    }

    private void addRecord(long amount, long time, long duration) {
        int count = Math.min(MAX_RECORDS, prefs.getInt("records_count", 0));
        android.content.SharedPreferences.Editor e = prefs.edit();

        for (int i = count; i >= 1; i--) {
            if (i < MAX_RECORDS) {
                e.putLong("record_amount_" + i, prefs.getLong("record_amount_" + (i - 1), 0));
                e.putLong("record_time_" + i, prefs.getLong("record_time_" + (i - 1), 0));
                e.putLong("record_duration_" + i, prefs.getLong("record_duration_" + (i - 1), 0));
            }
        }

        e.putLong("record_amount_0", amount);
        e.putLong("record_time_0", time);
        e.putLong("record_duration_0", duration);
        e.putInt("records_count", Math.min(MAX_RECORDS, count + 1));
        e.apply();
    }

    private void showStats() {
        heading("Статистика", "Твой заработок за выбранные периоды");

        long today = 0, week = 0;
        int todayTrips = 0, weekTrips = 0;
        Calendar now = Calendar.getInstance();
        Calendar day = Calendar.getInstance();
        day.set(Calendar.HOUR_OF_DAY, 0);
        day.set(Calendar.MINUTE, 0);
        day.set(Calendar.SECOND, 0);
        day.set(Calendar.MILLISECOND, 0);

        Calendar weekStart = (Calendar)day.clone();
        weekStart.add(Calendar.DAY_OF_YEAR, -6);

        int count = Math.min(MAX_RECORDS, prefs.getInt("records_count", 0));

        for (int i = 0; i < count; i++) {
            long time = readRecord("record_time_", i);
            long amount = readRecord("record_amount_", i);
            if (time >= day.getTimeInMillis()) {
                today += amount;
                todayTrips++;
            }
            if (time >= weekStart.getTimeInMillis()) {
                week += amount;
                weekTrips++;
            }
        }

        LinearLayout a = card();
        a.addView(text("СЕГОДНЯ", 12, muted(), true));
        a.addView(text(money(today) + " ₽", 29, accent(), true));
        a.addView(text("Кругов: " + todayTrips, 14, fg(), false));

        LinearLayout b = card();
        b.addView(text("ПОСЛЕДНИЕ 7 ДНЕЙ", 12, muted(), true));
        b.addView(text(money(week) + " ₽", 29, accent(), true));
        b.addView(text("Кругов: " + weekTrips, 14, fg(), false));

        LinearLayout all = card();
        all.addView(text("ЗА ВСЁ ВРЕМЯ", 12, muted(), true));
        all.addView(text(money(balance) + " ₽", 25, fg(), true));
        all.addView(text("Всего кругов: " + trips, 14, fg(), false));
    }

    private long readRecord(String prefix, int i) {
        return prefs.getLong(prefix + i, 0);
    }

    private void showHistory() {
        heading("История кругов", "Последние 200 записей");

        int count = Math.min(MAX_RECORDS, prefs.getInt("records_count", 0));

        if (count == 0) {
            card().addView(text("Пока нет записей. Добавь первый круг!", 14, muted(), false));
            return;
        }

        SimpleDateFormat fmt = new SimpleDateFormat("dd.MM.yyyy  HH:mm", Locale.getDefault());

        for (int i = 0; i < count; i++) {
            long amount = readRecord("record_amount_", i);
            long time = readRecord("record_time_", i);
            long duration = readRecord("record_duration_", i);

            LinearLayout c = card();
            c.addView(text("Круг №" + (count - i), 12, muted(), true));
            c.addView(text("+" + money(amount) + " ₽", 21, accent(), true));
            c.addView(text(time > 0 ? fmt.format(new Date(time)) : "Время неизвестно", 12, fg(), false));
            if (duration > 0) c.addView(text("Длительность: " + formatTime(duration), 12, muted(), false));
        }
    }

    private void showCalculator() {
        heading("Калькулятор цели", "Рассчитай, сколько осталось до накоплений");

        LinearLayout c = card();
        c.addView(text("Текущий баланс", 12, muted(), true));
        c.addView(text(money(balance) + " ₽", 25, fg(), true));
        c.addView(text("Цель: " + money(goal()) + " ₽", 14, muted(), false));

        long remaining = Math.max(0, goal() - balance);
        long rounds = (remaining + pay() - 1) / pay();

        c.addView(text("Осталось: " + money(remaining) + " ₽", 18, accent(), true));
        c.addView(text("Нужно кругов: " + rounds, 20, fg(), true));

        EditText custom = new EditText(this);
        custom.setSingleLine(true);
        custom.setInputType(2);
        custom.setHint("Сколько кругов в день?");
        custom.setTextColor(fg());
        custom.setHintTextColor(muted());
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, dp(52));
        ep.topMargin = dp(12);
        c.addView(custom, ep);

        Button calculate = button("РАССЧИТАТЬ СРОК", accent());
        c.addView(calculate, new LinearLayout.LayoutParams(-1, dp(48)));

        TextView result = text("", 15, accent(), true);
        c.addView(result);

        calculate.setOnClickListener(v -> {
            try {
                long perDay = Long.parseLong(custom.getText().toString().trim());
                if (perDay <= 0) throw new Exception();
                long days = (rounds + perDay - 1) / perDay;
                result.setText("При " + perDay + " кругах в день цель будет достигнута примерно за " + days + " дней.");
            } catch (Exception e) {
                result.setText("Введи количество кругов в день.");
            }
        });
    }

    private void showCharts() {
        heading("Графики", "Заработок по дням за последнюю неделю");

        LinearLayout c = card();
        c.addView(new EarningsChart(this), new LinearLayout.LayoutParams(-1, dp(220)));

        LinearLayout info = card();
        info.addView(text("График строится по сохранённой истории кругов.", 13, muted(), false));
    }

    private class EarningsChart extends View {
        Paint paint = new Paint(3);

        EarningsChart(Context c) { super(c); }

        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth(), h = getHeight();
            long[] values = new long[7];

            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.HOUR_OF_DAY, 0);
            cal.set(Calendar.MINUTE, 0);
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);

            long[] starts = new long[7];
            for (int i = 6; i >= 0; i--) {
                Calendar d = (Calendar)cal.clone();
                d.add(Calendar.DAY_OF_YEAR, -(6 - i));
                starts[i] = d.getTimeInMillis();
            }

            int count = Math.min(MAX_RECORDS, prefs.getInt("records_count", 0));
            for (int i = 0; i < count; i++) {
                long t = readRecord("record_time_", i);
                long amount = readRecord("record_amount_", i);
                for (int j = 0; j < 7; j++) {
                    long end = starts[j] + 86400000L;
                    if (t >= starts[j] && t < end) values[j] += amount;
                }
            }

            long max = 1;
            for (long v : values) max = Math.max(max, v);

            paint.setColor(muted());
            paint.setStrokeWidth(dp(1));
            canvas.drawLine(dp(8), h - dp(25), w - dp(8), h - dp(25), paint);

            float gap = dp(9);
            float barW = (w - dp(24) - gap * 6) / 7f;
            float base = h - dp(28);
            float maxHeight = h - dp(55);

            paint.setColor(accent());
            for (int i = 0; i < 7; i++) {
                float bh = (float)(values[i] * maxHeight / max);
                float left = dp(12) + i * (barW + gap);
                canvas.drawRoundRect(left, base - bh, left + barW, base, dp(6), dp(6), paint);
            }

            paint.setTextSize(dp(10));
            paint.setColor(fg());
            SimpleDateFormat f = new SimpleDateFormat("EE", Locale.getDefault());

            for (int i = 0; i < 7; i++) {
                Calendar d = (Calendar)cal.clone();
                d.add(Calendar.DAY_OF_YEAR, -(6 - i));
                String label = f.format(d.getTime());
                float left = dp(12) + i * (barW + gap);
                canvas.drawText(label, left, h - dp(7), paint);
            }
        }
    }

    private void showThemes() {
        heading("Оформление", "Выбери цветовую тему приложения");

        String[] names = {
            "Фиолетовая", "Белая", "Чёрная", "Красная", "Зелёная",
            "Жёлтая", "Синяя", "Голубая", "Розовая", "Оранжевая"
        };

        for (int i = 0; i < names.length; i++) {
            final int index = i;
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12), dp(10), dp(12), dp(10));
            row.setBackground(shape(cardColor(), 14));

            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(56));
            rp.topMargin = dp(7);
            content.addView(row, rp);

            View swatch = new View(this);
            swatch.setBackground(shape(accents[i], 30));
            row.addView(swatch, new LinearLayout.LayoutParams(dp(30), dp(30)));

            TextView name = text(names[i], 15, fg(), true);
            LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(0, -2, 1);
            np.leftMargin = dp(12);
            row.addView(name, np);

            TextView selected = text(prefs.getInt("theme", 0) == i ? "✓" : "›", 22, accents[i], true);
            row.addView(selected);

            row.setOnClickListener(v -> {
                prefs.edit().putInt("theme", index).apply();
                renderPage();
                Toast.makeText(this, "Тема изменена: " + names[index], Toast.LENGTH_SHORT).show();
            });
        }
    }

    private String formatTime(long sec) {
        return String.format(Locale.US, "%02d:%02d:%02d",
            sec / 3600, (sec % 3600) / 60, sec % 60);
    }

    private void toggleOverlay() {
        if (prefs.getBoolean("panel_enabled", false)) {
            stopService(new Intent(this, FloatingPanelService.class));
            prefs.edit().putBoolean("panel_enabled", false).apply();
            Toast.makeText(this, "Панель выключена", Toast.LENGTH_SHORT).show();
            return;
        }

        if (Build.VERSION.SDK_INT >= 23 && !android.provider.Settings.canDrawOverlays(this)) {
            Intent i = new Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                android.net.Uri.parse("package:" + getPackageName()));
            startActivity(i);
            return;
        }

        startService(new Intent(this, FloatingPanelService.class));
        Toast.makeText(this, "Панель включена", Toast.LENGTH_SHORT).show();
    }

    private void showSettings() {}

    @Override
    protected void onResume() {
        super.onResume();
        syncData();
        renderPage();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(ticker);
        if (prefs != null && listener != null) {
            prefs.unregisterOnSharedPreferenceChangeListener(listener);
        }
        super.onDestroy();
    }
}