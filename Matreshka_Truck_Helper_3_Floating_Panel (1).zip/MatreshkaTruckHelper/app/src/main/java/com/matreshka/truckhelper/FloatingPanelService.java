﻿package com.matreshka.truckhelper;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.content.*;
import android.provider.Settings;
import android.content.res.ColorStateList;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class FloatingPanelService extends Service {

    private static final int MAX_RECORDS = 200;

    private WindowManager wm;
    private View tab, panel;
    private WindowManager.LayoutParams tabLp, panelLp;
    private android.content.SharedPreferences prefs;
    private android.content.SharedPreferences.OnSharedPreferenceChangeListener listener;

    private boolean expanded = false;
    private boolean editing = false;

    private TextView earnings, count, progressText;
    private Button round, undoButton;
    private EditText payInput, goalInput;
    private LinearLayout settingsBox;
    private ProgressBar progressBar;

    private final int[] accents = {
        0xFF8B4DEB, 0xFF475569, 0xFF999999, 0xFFEF4444,
        0xFF22C55E, 0xFFEAB308, 0xFF3B82F6, 0xFF06B6D4,
        0xFFEC4899, 0xFFF97316
    };

    private final int[] backgrounds = {
        0xFF100D1C, 0xFFF1F5F9, 0xFF080808, 0xFF190B10,
        0xFF0B2115, 0xFF211C0A, 0xFF0C1830, 0xFF09232B,
        0xFF2A1022, 0xFF2A170C
    };

    private final int[] cards = {
        0xFF211735, 0xFFFFFFFF, 0xFF1B1B1B, 0xFF2A151C,
        0xFF142D20, 0xFF30280E, 0xFF172849, 0xFF12313A,
        0xFF3A1830, 0xFF3A2113
    };

    private final int[] foregrounds = {
        Color.WHITE, 0xFF172033, Color.WHITE, Color.WHITE,
        Color.WHITE, Color.WHITE, Color.WHITE, Color.WHITE,
        Color.WHITE, Color.WHITE
    };

    private int theme() {
        return Math.max(0, Math.min(9, prefs.getInt("theme", 0)));
    }

    private int accent() { return accents[theme()]; }
    private int background() { return backgrounds[theme()]; }
    private int cardColor() { return cards[theme()]; }
    private int fg() { return foregrounds[theme()]; }

    private int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private TextView txt(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    private Button btn(String s, int color) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(fg());
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setTypeface(null, Typeface.BOLD);
        b.setBackground(shape(color, 12));
        return b;
    }

    private String money(long n) {
        return NumberFormat.getIntegerInstance(new Locale("ru", "RU")).format(n);
    }

    private boolean canAdd(long a, long b) {
        return a >= 0 && b >= 0 && a <= Long.MAX_VALUE - b;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        prefs = getSharedPreferences("truck_stats", MODE_PRIVATE);
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);

        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }

        listener = (p, key) -> {
            if (key == null) return;
            new Handler(Looper.getMainLooper()).post(() -> {
                refreshStats();
                refreshTheme();
            });
        };
        prefs.registerOnSharedPreferenceChangeListener(listener);

        try {
            makeTab();
            prefs.edit().putBoolean("panel_enabled", true).apply();
        } catch (Exception e) {
            stopSelf();
        }
    }

    private WindowManager.LayoutParams lp(int w, int h) {
        return new WindowManager.LayoutParams(
            w, h,
            Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );
    }

    private void makeTab() {
        TextView t = txt("🚛", 22, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(shape(accent(), 18));
        tab = t;

        tabLp = lp(dp(52), dp(58));
        tabLp.gravity = Gravity.TOP | Gravity.RIGHT;
        tabLp.y = dp(180);
        wm.addView(tab, tabLp);

        tab.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                return true;
            }
            if (e.getAction() == MotionEvent.ACTION_UP) {
                toggle();
                return true;
            }
            return true;
        });
    }

    private void toggle() {
        if (expanded) {
            if (panel != null) {
                try { wm.removeView(panel); } catch (Exception ignored) {}
                panel = null;
            }
            expanded = false;
            editing = false;
        } else {
            makePanel();
            expanded = true;
        }
    }

    private void makePanel() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(1);
        root.setPadding(dp(13), dp(13), dp(13), dp(13));
        root.setBackground(shape(background(), 20));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = txt("TRUCK HELPER", 15, fg(), true);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1));

        Button close = btn("×", cardColor());
        head.addView(close, new LinearLayout.LayoutParams(dp(42), dp(40)));
        close.setOnClickListener(v -> toggle());
        root.addView(head);

        earnings = txt("", 18, accent(), true);
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, -2);
        ep.topMargin = dp(12);
        root.addView(earnings, ep);

        count = txt("", 13, fg(), false);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.topMargin = dp(6);
        root.addView(count, cp);

        progressText = txt("", 12, accent(), true);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, -2);
        pp.topMargin = dp(12);
        root.addView(progressText, pp);

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgressTintList(ColorStateList.valueOf(accent()));
        LinearLayout.LayoutParams pb = new LinearLayout.LayoutParams(-1, dp(8));
        pb.topMargin = dp(6);
        root.addView(progressBar, pb);

        round = btn("", accent());
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(50));
        rp.topMargin = dp(14);
        root.addView(round, rp);
        round.setOnClickListener(v -> addRound());

        undoButton = btn("ОТМЕНИТЬ ПОСЛЕДНИЙ КРУГ", cardColor());
        LinearLayout.LayoutParams up = new LinearLayout.LayoutParams(-1, dp(42));
        up.topMargin = dp(7);
        root.addView(undoButton, up);
        undoButton.setOnClickListener(v -> undoRound());

        Button settings = btn("НАСТРОЙКИ ВЫПЛАТЫ И ЦЕЛИ", cardColor());
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, dp(44));
        sp.topMargin = dp(10);
        root.addView(settings, sp);

        settingsBox = new LinearLayout(this);
        settingsBox.setOrientation(1);
        settingsBox.setVisibility(View.GONE);
        settingsBox.setPadding(0, dp(8), 0, 0);

        settingsBox.addView(txt("Выплата за круг", 12, fg(), true));

        payInput = new EditText(this);
        payInput.setSingleLine(true);
        payInput.setInputType(2);
        payInput.setTextColor(fg());
        payInput.setText(String.valueOf(prefs.getInt("pay", 15000)));
        settingsBox.addView(payInput);

        settingsBox.addView(txt("Цель накоплений", 12, fg(), true));

        goalInput = new EditText(this);
        goalInput.setSingleLine(true);
        goalInput.setInputType(2);
        goalInput.setTextColor(fg());
        goalInput.setText(String.valueOf(prefs.getLong("goal", 5000000)));
        settingsBox.addView(goalInput);

        Button save = btn("СОХРАНИТЬ", accent());
        settingsBox.addView(save);

        Button cancel = btn("ОТМЕНА", cardColor());
        settingsBox.addView(cancel);

        root.addView(settingsBox);

        settings.setOnClickListener(v -> {
            boolean show = settingsBox.getVisibility() != View.VISIBLE;
            settingsBox.setVisibility(show ? View.VISIBLE : View.GONE);
            editing = show;
            setFocusable(show);

            if (show) {
                payInput.requestFocus();
                payInput.post(() -> {
                    InputMethodManager imm = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
                    if (imm != null) imm.showSoftInput(payInput, InputMethodManager.SHOW_IMPLICIT);
                });
            } else {
                hideKeyboard();
            }
        });

        save.setOnClickListener(v -> {
            try {
                long p = Long.parseLong(payInput.getText().toString().trim());
                long g = Long.parseLong(goalInput.getText().toString().trim());

                if (p <= 0 || p > Integer.MAX_VALUE || g <= 0) throw new Exception();

                prefs.edit().putInt("pay", (int)p).putLong("goal", g).apply();
                hideKeyboard();
                settingsBox.setVisibility(View.GONE);
                editing = false;
                setFocusable(false);
                refreshStats();

                Toast.makeText(this, "Настройки сохранены", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Введи корректные числа", Toast.LENGTH_SHORT).show();
            }
        });

        cancel.setOnClickListener(v -> {
            hideKeyboard();
            settingsBox.setVisibility(View.GONE);
            editing = false;
            setFocusable(false);
        });

        Button reset = btn("СБРОСИТЬ СТАТИСТИКУ", 0xFFB84040);
        LinearLayout.LayoutParams resetP = new LinearLayout.LayoutParams(-1, dp(42));
        resetP.topMargin = dp(8);
        root.addView(reset, resetP);

        reset.setOnClickListener(v -> new AlertDialog.Builder(this)
            .setTitle("Сбросить статистику?")
            .setMessage("Баланс, круги, время и история будут обнулены. Настройки выплаты и темы сохранятся.")
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Сбросить", (d, w) -> resetStats())
            .show());

        Button shift = btn("ЗАВЕРШИТЬ СМЕНУ", cardColor());
        LinearLayout.LayoutParams shiftP = new LinearLayout.LayoutParams(-1, dp(40));
        shiftP.topMargin = dp(7);
        root.addView(shift, shiftP);

        shift.setOnClickListener(v -> {
            prefs.edit().putLong("shiftEarned", 0).putLong("shiftTrips", 0).apply();
            refreshStats();
            Toast.makeText(this, "Смена завершена", Toast.LENGTH_SHORT).show();
        });

        panel = root;
        panelLp = lp(dp(300), -2);
        panelLp.gravity = Gravity.TOP | Gravity.RIGHT;
        panelLp.y = Math.max(dp(20), tabLp.y - dp(60));
        wm.addView(panel, panelLp);

        refreshStats();
    }

    private void addRound() {
        long pay = prefs.getInt("pay", 15000);
        long balance = prefs.getLong("balance", 0);
        long trips = prefs.getLong("trips", 0);
        long earned = prefs.getLong("shiftEarned", 0);
        long shiftTrips = prefs.getLong("shiftTrips", 0);

        if (pay <= 0 || !canAdd(balance, pay) || !canAdd(earned, pay) || trips == Long.MAX_VALUE) {
            Toast.makeText(this, "Невозможно добавить круг", Toast.LENGTH_SHORT).show();
            return;
        }

        long now = System.currentTimeMillis();
        addRecord(pay, now, 0);

        prefs.edit()
            .putLong("balance", balance + pay)
            .putLong("trips", trips + 1)
            .putLong("shiftEarned", earned + pay)
            .putLong("shiftTrips", shiftTrips + 1)
            .apply();

        refreshStats();
        Toast.makeText(this, "Круг учтён: +" + money(pay) + " ₽", Toast.LENGTH_SHORT).show();
    }

    private void addRecord(long amount, long time, long duration) {
        int count = Math.min(MAX_RECORDS, prefs.getInt("records_count", 0));
        android.content.SharedPreferences.Editor e = prefs.edit();

        for (int i = count; i >= 1; i--) {
            if (i < MAX_RECORDS) {
                e.putLong("record_amount_" + i, prefs.getLong("record_amount_" + (i - 1), 0));
                e.putLong("record_time_" + i, prefs.getLong("record_time_" + (i - 1), 0));
                e.putLong("record_duration_" + i, prefs.getLong("record_duration_" + (i - 1), 0));
            }
        }

        e.putLong("record_amount_0", amount);
        e.putLong("record_time_0", time);
        e.putLong("record_duration_0", duration);
        e.putInt("records_count", Math.min(MAX_RECORDS, count + 1));
        e.apply();
    }

    private void undoRound() {
        int count = Math.min(MAX_RECORDS, prefs.getInt("records_count", 0));

        if (count <= 0) {
            Toast.makeText(this, "Нет круга для отмены", Toast.LENGTH_SHORT).show();
            return;
        }

        long amount = prefs.getLong("record_amount_0", 0);
        long duration = prefs.getLong("record_duration_0", 0);

        if (amount <= 0) return;

        long balance = prefs.getLong("balance", 0);
        long trips = prefs.getLong("trips", 0);
        long earned = prefs.getLong("shiftEarned", 0);
        long shiftTrips = prefs.getLong("shiftTrips", 0);
        long seconds = prefs.getLong("seconds", 0);

        android.content.SharedPreferences.Editor e = prefs.edit();

        for (int i = 0; i < count - 1; i++) {
            e.putLong("record_amount_" + i, prefs.getLong("record_amount_" + (i + 1), 0));
            e.putLong("record_time_" + i, prefs.getLong("record_time_" + (i + 1), 0));
            e.putLong("record_duration_" + i, prefs.getLong("record_duration_" + (i + 1), 0));
        }

        e.remove("record_amount_" + (count - 1));
        e.remove("record_time_" + (count - 1));
        e.remove("record_duration_" + (count - 1));

        e.putInt("records_count", count - 1);
        e.putLong("balance", Math.max(0, balance - amount));
        e.putLong("trips", Math.max(0, trips - 1));
        e.putLong("shiftEarned", Math.max(0, earned - amount));
        e.putLong("shiftTrips", Math.max(0, shiftTrips - 1));
        e.putLong("seconds", Math.max(0, seconds - duration));
        e.apply();

        refreshStats();
        Toast.makeText(this, "Последний круг отменён", Toast.LENGTH_SHORT).show();
    }

    private void resetStats() {
        android.content.SharedPreferences.Editor e = prefs.edit();

        e.putLong("balance", 0);
        e.putLong("trips", 0);
        e.putLong("seconds", 0);
        e.putLong("shiftEarned", 0);
        e.putLong("shiftTrips", 0);
        e.putInt("records_count", 0);
        e.putBoolean("running", false);
        e.putLong("startAt", 0);

        for (int i = 0; i < MAX_RECORDS; i++) {
            e.remove("record_amount_" + i);
            e.remove("record_time_" + i);
            e.remove("record_duration_" + i);
        }

        e.apply();
        refreshStats();
        Toast.makeText(this, "Статистика сброшена", Toast.LENGTH_SHORT).show();
    }

    private void refreshStats() {
        if (prefs == null) return;

        long earned = prefs.getLong("shiftEarned", 0);
        long trips = prefs.getLong("trips", 0);
        long balance = prefs.getLong("balance", 0);
        long goal = prefs.getLong("goal", 5000000);
        int pay = prefs.getInt("pay", 15000);

        if (earnings != null) earnings.setText("Заработок за смену: " + money(earned) + " ₽");
        if (count != null) {
            count.setText("Кругов: " + trips + "\nОбщий баланс: " + money(balance) + " ₽");
        }
        if (round != null) round.setText("СДЕЛАЛ КРУГ  +" + money(pay) + " ₽");

        if (progressText != null && progressBar != null) {
            double percent = goal > 0 ? balance * 100.0 / goal : 0;
            progressBar.setProgress((int)Math.min(100, Math.max(0, percent)));
            progressText.setText("Прогресс: " + String.format(Locale.US, "%.1f", percent) +
                "%\nОсталось: " + money(Math.max(0, goal - balance)) + " ₽");
        }

        if (undoButton != null) {
            boolean has = prefs.getInt("records_count", 0) > 0;
            undoButton.setEnabled(has);
            undoButton.setAlpha(has ? 1f : 0.5f);
        }
    }

    private void refreshTheme() {
        if (tab != null) {
            tab.setBackground(shape(accent(), 18));
        }

        if (panel != null && !editing) {
            toggle();
            makePanel();
            expanded = true;
        }
    }

    private void setFocusable(boolean focusable) {
        if (panel == null || panelLp == null) return;

        panelLp.flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        if (!focusable) panelLp.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;

        wm.updateViewLayout(panel, panelLp);
    }

    private void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null && payInput != null) {
                imm.hideSoftInputFromWindow(payInput.getWindowToken(), 0);
            }
        } catch (Exception ignored) {}
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        hideKeyboard();

        if (prefs != null) {
            prefs.unregisterOnSharedPreferenceChangeListener(listener);
            prefs.edit().putBoolean("panel_enabled", false).apply();
        }

        try { if (tab != null) wm.removeView(tab); } catch (Exception ignored) {}
        try { if (panel != null) wm.removeView(panel); } catch (Exception ignored) {}

        tab = null;
        panel = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}