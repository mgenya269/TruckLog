﻿
package com.matreshka.truckhelper;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.content.*;
import android.provider.Settings;

import java.text.NumberFormat;
import java.util.Locale;

public class FloatingPanelService extends Service {

    private WindowManager wm;
    private View tab, panel;
    private WindowManager.LayoutParams tabLp, panelLp;
    private android.content.SharedPreferences prefs;

    private boolean expanded = false;
    private boolean editing = false;
    private boolean resetting = false;

    private TextView earnings, count, progressText;
    private Button round;
    private EditText payInput, goalInput;

    private LinearLayout settingsBox;
    private LinearLayout resetConfirmBox;
    private ProgressBar progressBar;

    private int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable shape(int c, int r) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(c);
        d.setCornerRadius(dp(r));
        return d;
    }

    private TextView txt(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, 1);
        return t;
    }

    private Button btn(String s, int color) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(Color.WHITE);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setBackground(shape(color, 12));
        return b;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        prefs = getSharedPreferences("truck_stats", MODE_PRIVATE);
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);

        if (Build.VERSION.SDK_INT >= 23 &&
                !Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }

        makeTab();
    }

    private WindowManager.LayoutParams lp(int w, int h) {
        return new WindowManager.LayoutParams(
            w,
            h,
            Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );
    }

    private void makeTab() {
        tab = txt("🚛", 22, Color.WHITE, true);
        ((TextView)tab).setGravity(Gravity.CENTER);
        tab.setBackground(shape(0xEE18A879, 18));

        tabLp = lp(dp(52), dp(58));
        tabLp.gravity = Gravity.TOP | Gravity.RIGHT;
        tabLp.y = dp(180);

        wm.addView(tab, tabLp);

        tab.setOnTouchListener(new View.OnTouchListener() {
            float sy;
            int oy;

            @Override
            public boolean onTouch(View v, MotionEvent e) {

                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    sy = e.getRawY();
                    oy = tabLp.y;
                    return true;
                }

                if (e.getAction() == MotionEvent.ACTION_UP) {
                    if (Math.abs(e.getRawY() - sy) < dp(8)) {
                        toggle();
                    }
                    return true;
                }

                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    tabLp.y = Math.max(
                        0,
                        oy + (int)(e.getRawY() - sy)
                    );

                    wm.updateViewLayout(tab, tabLp);
                    return true;
                }

                return true;
            }
        });
    }

    private void toggle() {
        if (expanded) {
            hideKeyboard();

            if (panel != null) {
                wm.removeView(panel);
                panel = null;
            }

            expanded = false;
            editing = false;
            resetting = false;

        } else {
            makePanel();
            expanded = true;
        }
    }

    private void makePanel() {

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(14), dp(14), dp(14));
        root.setBackground(shape(0xF21D2733, 18));

        // ЗАГОЛОВОК

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = txt("TRUCK HELPER", 15, Color.WHITE, true);

        head.addView(title,
            new LinearLayout.LayoutParams(0, -2, 1));

        Button close = btn("×", 0xFF344354);
        head.addView(close,
            new LinearLayout.LayoutParams(dp(42), dp(40)));

        close.setOnClickListener(v -> toggle());

        root.addView(head);

        // ЗАРАБОТОК ЗА СМЕНУ

        earnings = txt("", 16, 0xFF55D6A2, true);

        LinearLayout.LayoutParams ep =
            new LinearLayout.LayoutParams(-1, -2);

        ep.topMargin = dp(12);
        root.addView(earnings, ep);

        // СТАТИСТИКА

        count = txt("", 12, Color.WHITE, false);

        LinearLayout.LayoutParams cp =
            new LinearLayout.LayoutParams(-1, -2);

        cp.topMargin = dp(5);
        root.addView(count, cp);

        // ПРОГРЕСС ЦЕЛИ

        progressText = txt("", 12, 0xFF55D6A2, true);

        LinearLayout.LayoutParams ptp =
            new LinearLayout.LayoutParams(-1, -2);

        ptp.topMargin = dp(12);
        root.addView(progressText, ptp);

        progressBar = new ProgressBar(
            this,
            null,
            android.R.attr.progressBarStyleHorizontal
        );

        progressBar.setMax(100);
        progressBar.setProgress(0);

        LinearLayout.LayoutParams pbp =
            new LinearLayout.LayoutParams(-1, dp(9));

        pbp.topMargin = dp(6);
        root.addView(progressBar, pbp);

        // КНОПКА СДЕЛАЛ КРУГ

        round = btn("", 0xFF20B989);

        LinearLayout.LayoutParams rp =
            new LinearLayout.LayoutParams(-1, dp(52));

        rp.topMargin = dp(14);
        root.addView(round, rp);

        round.setOnClickListener(v -> {

            int pay = prefs.getInt("pay", 15000);

            long trips = prefs.getLong("trips", 0) + 1;
            long balance = prefs.getLong("balance", 0) + pay;
            long earned = prefs.getLong("shiftEarned", 0) + pay;

            prefs.edit()
                .putLong("trips", trips)
                .putLong("balance", balance)
                .putLong("shiftEarned", earned)
                .apply();

            refreshStats();

            Toast.makeText(
                this,
                "Круг учтён: +" + money(pay) + " ₽",
                Toast.LENGTH_SHORT
            ).show();
        });

        // НАСТРОЙКИ

        Button settings = btn(
            "НАСТРОЙКИ ВЫПЛАТЫ И ЦЕЛИ",
            0xFF344354
        );

        LinearLayout.LayoutParams sp =
            new LinearLayout.LayoutParams(-1, dp(46));

        sp.topMargin = dp(8);
        root.addView(settings, sp);

        settingsBox = new LinearLayout(this);
        settingsBox.setOrientation(LinearLayout.VERTICAL);
        settingsBox.setPadding(0, dp(8), 0, 0);
        settingsBox.setVisibility(View.GONE);

        settingsBox.addView(
            txt("Выплата за круг", 12, Color.WHITE, false)
        );

        payInput = new EditText(this);
        payInput.setSingleLine(true);
        payInput.setTextColor(Color.WHITE);
        payInput.setHintTextColor(0xFFAAAAAA);
        payInput.setHint("Сумма выплаты");
        payInput.setInputType(2);
        payInput.setText(
            String.valueOf(prefs.getInt("pay", 15000))
        );
        payInput.setSelectAllOnFocus(true);

        settingsBox.addView(payInput);

        settingsBox.addView(
            txt("Цель накоплений", 12, Color.WHITE, false)
        );

        goalInput = new EditText(this);
        goalInput.setSingleLine(true);
        goalInput.setTextColor(Color.WHITE);
        goalInput.setHintTextColor(0xFFAAAAAA);
        goalInput.setHint("Целевая сумма");
        goalInput.setInputType(2);
        goalInput.setText(
            String.valueOf(prefs.getLong("goal", 5000000))
        );
        goalInput.setSelectAllOnFocus(true);

        settingsBox.addView(goalInput);

        Button save = btn("СОХРАНИТЬ", 0xFF20B989);
        settingsBox.addView(save);

        Button cancel = btn("ОТМЕНА", 0xFF344354);
        settingsBox.addView(cancel);

        root.addView(settingsBox);

        settings.setOnClickListener(v -> {

            if (editing) {
                hideKeyboard();
                settingsBox.setVisibility(View.GONE);
                setPanelFocusable(false);
                editing = false;

            } else {
                editing = true;

                // Скрываем подтверждение сброса
                resetConfirmBox.setVisibility(View.GONE);
                resetting = false;

                settingsBox.setVisibility(View.VISIBLE);
                setPanelFocusable(true);

                payInput.requestFocus();

                payInput.post(() -> {
                    InputMethodManager imm =
                        (InputMethodManager)getSystemService(
                            INPUT_METHOD_SERVICE
                        );

                    if (imm != null) {
                        imm.showSoftInput(
                            payInput,
                            InputMethodManager.SHOW_IMPLICIT
                        );
                    }
                });
            }
        });

        save.setOnClickListener(v -> {

            try {
                long p = Long.parseLong(
                    payInput.getText().toString().trim()
                );

                long g = Long.parseLong(
                    goalInput.getText().toString().trim()
                );

                if (p < 1 || g < 1 || p > Integer.MAX_VALUE) {
                    throw new Exception();
                }

                prefs.edit()
                    .putInt("pay", (int)p)
                    .putLong("goal", g)
                    .apply();

                hideKeyboard();

                settingsBox.setVisibility(View.GONE);
                setPanelFocusable(false);
                editing = false;

                refreshStats();

                Toast.makeText(
                    this,
                    "Настройки сохранены!",
                    Toast.LENGTH_SHORT
                ).show();

            } catch (Exception e) {
                Toast.makeText(
                    this,
                    "Введи корректные положительные числа",
                    Toast.LENGTH_SHORT
                ).show();
            }
        });

        cancel.setOnClickListener(v -> {
            hideKeyboard();
            settingsBox.setVisibility(View.GONE);
            setPanelFocusable(false);
            editing = false;
        });

        // ЗАВЕРШЕНИЕ СМЕНЫ

        Button shift = btn("ЗАВЕРШИТЬ СМЕНУ", 0xFF344354);

        LinearLayout.LayoutParams sh =
            new LinearLayout.LayoutParams(-1, dp(44));

        sh.topMargin = dp(8);
        root.addView(shift, sh);

        shift.setOnClickListener(v -> {

            prefs.edit()
                .putLong("shiftEarned", 0)
                .apply();

            refreshStats();

            Toast.makeText(
                this,
                "Смена завершена. Общий баланс сохранён.",
                Toast.LENGTH_SHORT
            ).show();
        });

        // СБРОС СТАТИСТИКИ

        Button reset = btn(
            "СБРОСИТЬ СТАТИСТИКУ",
            0xFFB84040
        );

        LinearLayout.LayoutParams resetParams =
            new LinearLayout.LayoutParams(-1, dp(44));

        resetParams.topMargin = dp(8);
        root.addView(reset, resetParams);

        // Подтверждение сброса прямо в панели

        resetConfirmBox = new LinearLayout(this);
        resetConfirmBox.setOrientation(LinearLayout.VERTICAL);
        resetConfirmBox.setPadding(
            dp(10), dp(10), dp(10), dp(10)
        );
        resetConfirmBox.setBackground(shape(0xFF303E4D, 12));
        resetConfirmBox.setVisibility(View.GONE);

        TextView warning = txt(
            "Ты действительно хочешь обнулить круги, баланс и заработок смены? Это действие нельзя отменить.",
            12,
            Color.WHITE,
            false
        );

        resetConfirmBox.addView(warning);

        Button confirmReset = btn(
            "ДА, СБРОСИТЬ",
            0xFFB84040
        );

        LinearLayout.LayoutParams crp =
            new LinearLayout.LayoutParams(-1, dp(42));

        crp.topMargin = dp(8);
        resetConfirmBox.addView(confirmReset, crp);

        Button cancelReset = btn(
            "ОТМЕНА",
            0xFF344354
        );

        LinearLayout.LayoutParams canp =
            new LinearLayout.LayoutParams(-1, dp(42));

        canp.topMargin = dp(5);
        resetConfirmBox.addView(cancelReset, canp);

        root.addView(resetConfirmBox);

        reset.setOnClickListener(v -> {

            hideKeyboard();

            settingsBox.setVisibility(View.GONE);
            editing = false;

            setPanelFocusable(false);

            resetting = true;
            resetConfirmBox.setVisibility(View.VISIBLE);
        });

        confirmReset.setOnClickListener(v -> {

            if (!resetting) return;

            prefs.edit()
                .putLong("trips", 0)
                .putLong("balance", 0)
                .putLong("shiftEarned", 0)
                .apply();

            resetting = false;
            resetConfirmBox.setVisibility(View.GONE);

            refreshStats();

            Toast.makeText(
                this,
                "Статистика успешно сброшена!",
                Toast.LENGTH_SHORT
            ).show();
        });

        cancelReset.setOnClickListener(v -> {
            resetting = false;
            resetConfirmBox.setVisibility(View.GONE);
        });

        // СОЗДАНИЕ ОКНА

        panel = root;

        panelLp = lp(dp(290), -2);
        panelLp.gravity = Gravity.TOP | Gravity.RIGHT;
        panelLp.y = Math.max(dp(20), tabLp.y - dp(60));
        panelLp.softInputMode =
            WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE;

        wm.addView(panel, panelLp);

        refreshStats();
    }

    private void setPanelFocusable(boolean focusable) {

        if (panel == null || panelLp == null) return;

        if (focusable) {
            panelLp.flags =
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;

        } else {
            panelLp.flags =
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        }

        wm.updateViewLayout(panel, panelLp);
    }

    private void hideKeyboard() {

        try {
            InputMethodManager imm =
                (InputMethodManager)getSystemService(
                    INPUT_METHOD_SERVICE
                );

            if (imm != null && panel != null) {
                imm.hideSoftInputFromWindow(
                    panel.getWindowToken(),
                    0
                );
            }

        } catch (Exception ignored) {}
    }

    // ОБНОВЛЕНИЕ СТАТИСТИКИ И ПРОГРЕССА

    private void refreshStats() {

        if (prefs == null) return;

        long earned = prefs.getLong("shiftEarned", 0);
        long trips = prefs.getLong("trips", 0);
        long balance = prefs.getLong("balance", 0);
        long goal = prefs.getLong("goal", 5000000);

        int pay = prefs.getInt("pay", 15000);

        if (earnings != null) {
            earnings.setText(
                "Заработано за смену: " +
                money(earned) + " ₽"
            );
        }

        if (count != null) {
            count.setText(
                "Кругов: " + trips +
                "\nОбщий баланс: " + money(balance) + " ₽" +
                "\nЦель: " + money(goal) + " ₽"
            );
        }

        if (round != null) {
            round.setText(
                "СДЕЛАЛ КРУГ  +" + money(pay) + " ₽"
            );
        }

        if (progressText != null && progressBar != null) {

            double percent = goal > 0
                ? (balance * 100.0 / goal)
                : 0;

            int progress = (int)Math.min(
                100,
                Math.max(0, Math.round(percent))
            );

            long remaining = Math.max(0, goal - balance);

            progressBar.setProgress(progress);

            progressText.setText(
                "Прогресс: " +
                String.format(Locale.US, "%.1f", percent) +
                "%\n" +
                (remaining > 0
                    ? "Осталось: " + money(remaining) + " ₽"
                    : "ЦЕЛЬ ДОСТИГНУТА!")
            );
        }
    }

    private String money(long n) {
        return NumberFormat.getIntegerInstance(
            new Locale("ru", "RU")
        ).format(n);
    }

    @Override
    public int onStartCommand(Intent i, int f, int id) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {

        try {
            hideKeyboard();

            if (tab != null) {
                wm.removeView(tab);
                tab = null;
            }

            if (panel != null) {
                wm.removeView(panel);
                panel = null;
            }

        } catch (Exception ignored) {}

        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }
}
