﻿
package com.matreshka.truckhelper;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.content.*;
import android.provider.Settings;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class FloatingPanelService extends Service {

    private static final int HISTORY_LIMIT = 20;

    private WindowManager wm;
    private View tab, panel;
    private WindowManager.LayoutParams tabLp, panelLp;
    private android.content.SharedPreferences prefs;

    private boolean expanded = false;
    private boolean editing = false;
    private boolean resetting = false;

    private TextView earnings, count, progressText, historyText;
    private Button round, undoButton;
    private EditText payInput, goalInput;

    private LinearLayout settingsBox;
    private LinearLayout resetConfirmBox;
    private ProgressBar progressBar;

    private int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private TextView txt(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, 1);
        return t;
    }

    private Button btn(String s, int color) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(Color.WHITE);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setBackground(shape(color, 12));
        return b;
    }

    private String money(long n) {
        return NumberFormat.getIntegerInstance(
            new Locale("ru", "RU")
        ).format(n);
    }

    private boolean canAdd(long a, long b) {
        return b >= 0 && a >= 0 && a <= Long.MAX_VALUE - b;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        prefs = getSharedPreferences("truck_stats", MODE_PRIVATE);
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);

        if (Build.VERSION.SDK_INT >= 23 &&
                !Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }

        makeTab();
    }

    private WindowManager.LayoutParams lp(int w, int h) {
        return new WindowManager.LayoutParams(
            w,
            h,
            Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );
    }

    // БОКОВАЯ КНОПКА

    private void makeTab() {
        tab = txt("🚛", 22, Color.WHITE, true);
        ((TextView)tab).setGravity(Gravity.CENTER);
        tab.setBackground(shape(0xEE18A879, 18));

        tabLp = lp(dp(52), dp(58));
        tabLp.gravity = Gravity.TOP | Gravity.RIGHT;
        tabLp.y = dp(180);

        wm.addView(tab, tabLp);

        tab.setOnTouchListener(new View.OnTouchListener() {
            float startY;
            int startPosition;

            @Override
            public boolean onTouch(View v, MotionEvent e) {

                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    startY = e.getRawY();
                    startPosition = tabLp.y;
                    return true;
                }

                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    int screenHeight =
                        getResources().getDisplayMetrics().heightPixels;

                    int maxY = Math.max(
                        0,
                        screenHeight - dp(58)
                    );

                    tabLp.y = Math.max(
                        0,
                        Math.min(
                            maxY,
                            startPosition + (int)(e.getRawY() - startY)
                        )
                    );

                    wm.updateViewLayout(tab, tabLp);
                    return true;
                }

                if (e.getAction() == MotionEvent.ACTION_UP) {
                    if (Math.abs(e.getRawY() - startY) < dp(8)) {
                        toggle();
                    }
                    return true;
                }

                return true;
            }
        });
    }

    // ОТКРЫТИЕ И ЗАКРЫТИЕ

    private void toggle() {
        if (expanded) {
            hideKeyboard();

            if (panel != null) {
                try {
                    wm.removeView(panel);
                } catch (Exception ignored) {}
                panel = null;
            }

            expanded = false;
            editing = false;
            resetting = false;

        } else {
            makePanel();
            expanded = true;
        }
    }

    // СОЗДАНИЕ ПАНЕЛИ

    private void makePanel() {

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(12), dp(12), dp(12));
        root.setBackground(shape(0xF21D2733, 18));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setVerticalScrollBarEnabled(true);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);

        scroll.addView(content);

        root.addView(
            scroll,
            new LinearLayout.LayoutParams(-1, dp(540))
        );

        // ЗАГОЛОВОК

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = txt(
            "TRUCK HELPER",
            15,
            Color.WHITE,
            true
        );

        head.addView(
            title,
            new LinearLayout.LayoutParams(0, -2, 1)
        );

        Button close = btn("×", 0xFF344354);

        head.addView(
            close,
            new LinearLayout.LayoutParams(dp(42), dp(40))
        );

        close.setOnClickListener(v -> toggle());

        content.addView(head);

        // ЗАРАБОТОК

        earnings = txt("", 16, 0xFF55D6A2, true);

        LinearLayout.LayoutParams ep =
            new LinearLayout.LayoutParams(-1, -2);

        ep.topMargin = dp(12);
        content.addView(earnings, ep);

        // СТАТИСТИКА

        count = txt("", 12, Color.WHITE, false);

        LinearLayout.LayoutParams cp =
            new LinearLayout.LayoutParams(-1, -2);

        cp.topMargin = dp(5);
        content.addView(count, cp);

        // ПРОГРЕСС ЦЕЛИ

        progressText = txt("", 12, 0xFF55D6A2, true);

        LinearLayout.LayoutParams ptp =
            new LinearLayout.LayoutParams(-1, -2);

        ptp.topMargin = dp(12);
        content.addView(progressText, ptp);

        progressBar = new ProgressBar(
            this,
            null,
            android.R.attr.progressBarStyleHorizontal
        );

        progressBar.setMax(100);
        progressBar.setProgress(0);

        LinearLayout.LayoutParams pbp =
            new LinearLayout.LayoutParams(-1, dp(9));

        pbp.topMargin = dp(6);
        content.addView(progressBar, pbp);

        // КНОПКА КРУГА

        round = btn("", 0xFF20B989);

        LinearLayout.LayoutParams rp =
            new LinearLayout.LayoutParams(-1, dp(52));

        rp.topMargin = dp(14);
        content.addView(round, rp);

        round.setOnClickListener(v -> addRound());

        // ОТМЕНА ПОСЛЕДНЕГО КРУГА

        undoButton = btn(
            "ОТМЕНИТЬ ПОСЛЕДНИЙ КРУГ",
            0xFFB87932
        );

        LinearLayout.LayoutParams up =
            new LinearLayout.LayoutParams(-1, dp(44));

        up.topMargin = dp(7);
        content.addView(undoButton, up);

        undoButton.setOnClickListener(v -> undoRound());

        // ЖУРНАЛ

        TextView historyTitle = txt(
            "ПОСЛЕДНИЕ КРУГИ",
            12,
            0xFF55D6A2,
            true
        );

        LinearLayout.LayoutParams htp =
            new LinearLayout.LayoutParams(-1, -2);

        htp.topMargin = dp(14);
        content.addView(historyTitle, htp);

        historyText = txt(
            "Пока нет записей",
            11,
            Color.WHITE,
            false
        );

        historyText.setPadding(
            dp(9), dp(8), dp(9), dp(8)
        );

        historyText.setBackground(shape(0xFF293744, 10));

        LinearLayout.LayoutParams hxp =
            new LinearLayout.LayoutParams(-1, -2);

        hxp.topMargin = dp(6);
        content.addView(historyText, hxp);

        // НАСТРОЙКИ

        Button settings = btn(
            "НАСТРОЙКИ ВЫПЛАТЫ И ЦЕЛИ",
            0xFF344354
        );

        LinearLayout.LayoutParams sp =
            new LinearLayout.LayoutParams(-1, dp(46));

        sp.topMargin = dp(12);
        content.addView(settings, sp);

        settingsBox = new LinearLayout(this);
        settingsBox.setOrientation(LinearLayout.VERTICAL);
        settingsBox.setPadding(0, dp(8), 0, 0);
        settingsBox.setVisibility(View.GONE);

        settingsBox.addView(
            txt("Выплата за круг", 12, Color.WHITE, false)
        );

        payInput = new EditText(this);
        payInput.setSingleLine(true);
        payInput.setTextColor(Color.WHITE);
        payInput.setHintTextColor(0xFFAAAAAA);
        payInput.setHint("Сумма выплаты");
        payInput.setInputType(2);
        payInput.setText(
            String.valueOf(prefs.getInt("pay", 15000))
        );
        payInput.setSelectAllOnFocus(true);

        settingsBox.addView(payInput);

        settingsBox.addView(
            txt("Цель накоплений", 12, Color.WHITE, false)
        );

        goalInput = new EditText(this);
        goalInput.setSingleLine(true);
        goalInput.setTextColor(Color.WHITE);
        goalInput.setHintTextColor(0xFFAAAAAA);
        goalInput.setHint("Целевая сумма");
        goalInput.setInputType(2);
        goalInput.setText(
            String.valueOf(prefs.getLong("goal", 5000000))
        );
        goalInput.setSelectAllOnFocus(true);

        settingsBox.addView(goalInput);

        Button save = btn("СОХРАНИТЬ", 0xFF20B989);
        settingsBox.addView(save);

        Button cancel = btn("ОТМЕНА", 0xFF344354);
        settingsBox.addView(cancel);

        content.addView(settingsBox);

        settings.setOnClickListener(v -> {

            if (editing) {
                hideKeyboard();
                settingsBox.setVisibility(View.GONE);
                setPanelFocusable(false);
                editing = false;

            } else {
                editing = true;

                resetConfirmBox.setVisibility(View.GONE);
                resetting = false;

                settingsBox.setVisibility(View.VISIBLE);
                setPanelFocusable(true);

                payInput.requestFocus();

                payInput.post(() -> {
                    InputMethodManager imm =
                        (InputMethodManager)getSystemService(
                            INPUT_METHOD_SERVICE
                        );

                    if (imm != null) {
                        imm.showSoftInput(
                            payInput,
                            InputMethodManager.SHOW_IMPLICIT
                        );
                    }
                });
            }
        });

        save.setOnClickListener(v -> {

            try {
                String payText =
                    payInput.getText().toString().trim();

                String goalText =
                    goalInput.getText().toString().trim();

                long p = Long.parseLong(payText);
                long g = Long.parseLong(goalText);

                if (p < 1 || g < 1 ||
                        p > Integer.MAX_VALUE) {
                    throw new Exception();
                }

                prefs.edit()
                    .putInt("pay", (int)p)
                    .putLong("goal", g)
                    .apply();

                hideKeyboard();

                settingsBox.setVisibility(View.GONE);
                setPanelFocusable(false);
                editing = false;

                refreshStats();

                Toast.makeText(
                    this,
                    "Настройки сохранены!",
                    Toast.LENGTH_SHORT
                ).show();

            } catch (Exception e) {
                Toast.makeText(
                    this,
                    "Введи корректные положительные числа",
                    Toast.LENGTH_SHORT
                ).show();
            }
        });

        cancel.setOnClickListener(v -> {
            hideKeyboard();
            settingsBox.setVisibility(View.GONE);
            setPanelFocusable(false);
            editing = false;
        });

        // ЗАВЕРШЕНИЕ СМЕНЫ

        Button shift = btn(
            "ЗАВЕРШИТЬ СМЕНУ",
            0xFF344354
        );

        LinearLayout.LayoutParams sh =
            new LinearLayout.LayoutParams(-1, dp(44));

        sh.topMargin = dp(8);
        content.addView(shift, sh);

        shift.setOnClickListener(v -> {

            prefs.edit()
                .putLong("shiftEarned", 0)
                .apply();

            refreshStats();

            Toast.makeText(
                this,
                "Смена завершена. Общий баланс сохранён.",
                Toast.LENGTH_SHORT
            ).show();
        });

        // СБРОС СТАТИСТИКИ

        Button reset = btn(
            "СБРОСИТЬ СТАТИСТИКУ",
            0xFFB84040
        );

        LinearLayout.LayoutParams resetParams =
            new LinearLayout.LayoutParams(-1, dp(44));

        resetParams.topMargin = dp(8);
        content.addView(reset, resetParams);

        resetConfirmBox = new LinearLayout(this);
        resetConfirmBox.setOrientation(LinearLayout.VERTICAL);
        resetConfirmBox.setPadding(
            dp(10), dp(10), dp(10), dp(10)
        );
        resetConfirmBox.setBackground(shape(0xFF303E4D, 12));
        resetConfirmBox.setVisibility(View.GONE);

        TextView warning = txt(
            "Ты действительно хочешь обнулить круги, баланс, журнал и заработок смены? Это действие нельзя отменить.",
            12,
            Color.WHITE,
            false
        );

        resetConfirmBox.addView(warning);

        Button confirmReset = btn(
            "ДА, СБРОСИТЬ",
            0xFFB84040
        );

        LinearLayout.LayoutParams crp =
            new LinearLayout.LayoutParams(-1, dp(42));

        crp.topMargin = dp(8);
        resetConfirmBox.addView(confirmReset, crp);

        Button cancelReset = btn(
            "ОТМЕНА",
            0xFF344354
        );

        LinearLayout.LayoutParams canp =
            new LinearLayout.LayoutParams(-1, dp(42));

        canp.topMargin = dp(5);
        resetConfirmBox.addView(cancelReset, canp);

        content.addView(resetConfirmBox);

        reset.setOnClickListener(v -> {

            hideKeyboard();

            settingsBox.setVisibility(View.GONE);
            editing = false;

            setPanelFocusable(false);

            resetting = true;
            resetConfirmBox.setVisibility(View.VISIBLE);
        });

        confirmReset.setOnClickListener(v -> {

            if (!resetting) return;

            android.content.SharedPreferences.Editor editor =
                prefs.edit();

            editor.putLong("trips", 0);
            editor.putLong("balance", 0);
            editor.putLong("shiftEarned", 0);
            editor.putInt("historyCount", 0);

            for (int i = 0; i < HISTORY_LIMIT; i++) {
                editor.remove("historyAmount_" + i);
                editor.remove("historyTime_" + i);
            }

            editor.apply();

            resetting = false;
            resetConfirmBox.setVisibility(View.GONE);

            refreshStats();

            Toast.makeText(
                this,
                "Статистика успешно сброшена!",
                Toast.LENGTH_SHORT
            ).show();
        });

        cancelReset.setOnClickListener(v -> {
            resetting = false;
            resetConfirmBox.setVisibility(View.GONE);
        });

        // СОЗДАНИЕ ОКНА

        panel = root;

        panelLp = lp(dp(300), -2);
        panelLp.gravity = Gravity.TOP | Gravity.RIGHT;
        panelLp.y = Math.max(dp(20), tabLp.y - dp(60));
        panelLp.softInputMode =
            WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE;

        wm.addView(panel, panelLp);

        refreshStats();
    }

    // ДОБАВЛЕНИЕ КРУГА

    private void addRound() {

        int pay = prefs.getInt("pay", 15000);

        if (pay < 1) {
            Toast.makeText(
                this,
                "Сначала настрой выплату за круг",
                Toast.LENGTH_SHORT
            ).show();
            return;
        }

        long trips = prefs.getLong("trips", 0);
        long balance = prefs.getLong("balance", 0);
        long earned = prefs.getLong("shiftEarned", 0);

        if (trips == Long.MAX_VALUE ||
                !canAdd(balance, pay) ||
                !canAdd(earned, pay)) {

            Toast.makeText(
                this,
                "Достигнут предел числового счётчика",
                Toast.LENGTH_LONG
            ).show();
            return;
        }

        long now = System.currentTimeMillis();

        android.content.SharedPreferences.Editor editor =
            prefs.edit();

        editor.putLong("trips", trips + 1);
        editor.putLong("balance", balance + pay);
        editor.putLong("shiftEarned", earned + pay);

        // Сдвигаем старые записи журнала

        int oldCount = prefs.getInt("historyCount", 0);
        int newCount = Math.min(
            HISTORY_LIMIT,
            oldCount + 1
        );

        for (int i = newCount - 1; i >= 1; i--) {
            long oldAmount =
                prefs.getLong("historyAmount_" + (i - 1), 0);

            long oldTime =
                prefs.getLong("historyTime_" + (i - 1), 0);

            editor.putLong("historyAmount_" + i, oldAmount);
            editor.putLong("historyTime_" + i, oldTime);
        }

        editor.putLong("historyAmount_0", pay);
        editor.putLong("historyTime_0", now);
        editor.putInt("historyCount", newCount);

        editor.apply();

        refreshStats();

        Toast.makeText(
            this,
            "Круг учтён: +" + money(pay) + " ₽",
            Toast.LENGTH_SHORT
        ).show();
    }

    // ОТМЕНА ПОСЛЕДНЕГО КРУГА

    private void undoRound() {

        int historyCount = prefs.getInt("historyCount", 0);

        if (historyCount <= 0) {
            Toast.makeText(
                this,
                "Нет круга для отмены",
                Toast.LENGTH_SHORT
            ).show();
            return;
        }

        long amount =
            prefs.getLong("historyAmount_0", 0);

        if (amount <= 0) {
            Toast.makeText(
                this,
                "Не удалось прочитать последнюю запись",
                Toast.LENGTH_SHORT
            ).show();
            return;
        }

        long trips = prefs.getLong("trips", 0);
        long balance = prefs.getLong("balance", 0);
        long earned = prefs.getLong("shiftEarned", 0);

        android.content.SharedPreferences.Editor editor =
            prefs.edit();

        editor.putLong("trips", Math.max(0, trips - 1));
        editor.putLong("balance", Math.max(0, balance - amount));
        editor.putLong("shiftEarned", Math.max(0, earned - amount));

        // Удаляем последнюю запись и сдвигаем остальные

        for (int i = 0; i < historyCount - 1; i++) {
            long nextAmount =
                prefs.getLong("historyAmount_" + (i + 1), 0);

            long nextTime =
                prefs.getLong("historyTime_" + (i + 1), 0);

            editor.putLong("historyAmount_" + i, nextAmount);
            editor.putLong("historyTime_" + i, nextTime);
        }

        int newCount = historyCount - 1;

        editor.remove("historyAmount_" + newCount);
        editor.remove("historyTime_" + newCount);
        editor.putInt("historyCount", newCount);

        editor.apply();

        refreshStats();

        Toast.makeText(
            this,
            "Последний круг отменён: -" + money(amount) + " ₽",
            Toast.LENGTH_SHORT
        ).show();
    }

    // ОБНОВЛЕНИЕ СТАТИСТИКИ

    private void refreshStats() {

        if (prefs == null) return;

        long earned = prefs.getLong("shiftEarned", 0);
        long trips = prefs.getLong("trips", 0);
        long balance = prefs.getLong("balance", 0);
        long goal = prefs.getLong("goal", 5000000);

        int pay = prefs.getInt("pay", 15000);

        if (earnings != null) {
            earnings.setText(
                "Заработано за смену: " +
                money(earned) + " ₽"
            );
        }

        if (count != null) {
            count.setText(
                "Кругов: " + trips +
                "\nОбщий баланс: " + money(balance) + " ₽" +
                "\nЦель: " + money(goal) + " ₽"
            );
        }

        if (round != null) {
            round.setText(
                "СДЕЛАЛ КРУГ  +" + money(pay) + " ₽"
            );
        }

        if (progressText != null && progressBar != null) {

            double percent = goal > 0
                ? balance * 100.0 / goal
                : 0;

            int progress = (int)Math.min(
                100,
                Math.max(0, Math.round(percent))
            );

            long remaining = Math.max(0, goal - balance);

            progressBar.setProgress(progress);

            progressText.setText(
                "Прогресс: " +
                String.format(Locale.US, "%.1f", percent) +
                "%\n" +
                (remaining > 0
                    ? "Осталось: " + money(remaining) + " ₽"
                    : "ЦЕЛЬ ДОСТИГНУТА!")
            );
        }

        refreshHistory();
    }

    // ОБНОВЛЕНИЕ ЖУРНАЛА

    private void refreshHistory() {

        if (historyText == null) return;

        int total = prefs.getInt("historyCount", 0);
        int visible = Math.min(total, HISTORY_LIMIT);

        if (visible <= 0) {
            historyText.setText("Пока нет записей");
        } else {
            StringBuilder result = new StringBuilder();

            SimpleDateFormat format =
                new SimpleDateFormat("HH:mm", Locale.getDefault());

            for (int i = 0; i < visible; i++) {

                long amount =
                    prefs.getLong("historyAmount_" + i, 0);

                long time =
                    prefs.getLong("historyTime_" + i, 0);

                if (amount <= 0) continue;

                if (result.length() > 0) {
                    result.append("\n");
                }

                String timeText = time > 0
                    ? format.format(new Date(time))
                    : "--:--";

                result.append(timeText)
                    .append("  +")
                    .append(money(amount))
                    .append(" ₽");
            }

            historyText.setText(
                result.length() > 0
                    ? result.toString()
                    : "Пока нет записей"
            );
        }

        if (undoButton != null) {
            undoButton.setEnabled(visible > 0);
            undoButton.setAlpha(visible > 0 ? 1f : 0.5f);
        }
    }

    // УПРАВЛЕНИЕ ФОКУСОМ И КЛАВИАТУРОЙ

    private void setPanelFocusable(boolean focusable) {

        if (panel == null || panelLp == null) return;

        if (focusable) {
            panelLp.flags =
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        } else {
            panelLp.flags =
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        }

        wm.updateViewLayout(panel, panelLp);
    }

    private void hideKeyboard() {

        try {
            InputMethodManager imm =
                (InputMethodManager)getSystemService(
                    INPUT_METHOD_SERVICE
                );

            if (imm != null) {
                View target = payInput != null
                    ? payInput
                    : panel;

                if (target != null) {
                    imm.hideSoftInputFromWindow(
                        target.getWindowToken(),
                        0
                    );
                }
            }

        } catch (Exception ignored) {}
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {

        hideKeyboard();

        try {
            if (tab != null && wm != null) {
                wm.removeView(tab);
                tab = null;
            }
        } catch (Exception ignored) {}

        try {
            if (panel != null && wm != null) {
                wm.removeView(panel);
                panel = null;
            }
        } catch (Exception ignored) {}

        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}