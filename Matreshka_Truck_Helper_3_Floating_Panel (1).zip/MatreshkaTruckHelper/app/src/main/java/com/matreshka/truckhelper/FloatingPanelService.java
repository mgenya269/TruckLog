﻿package com.matreshka.truckhelper;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.content.*;
import android.provider.Settings;
import java.text.NumberFormat;
import java.util.Locale;

public class FloatingPanelService extends Service {
    private WindowManager wm;
    private View tab, panel;
    private WindowManager.LayoutParams tabLp, panelLp;
    private android.content.SharedPreferences prefs;
    private boolean expanded = false;
    private boolean editing = false;

    private TextView earnings, count;
    private Button round;
    private EditText payInput, goalInput;
    private LinearLayout settingsBox;

    private int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable shape(int c, int r) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(c);
        d.setCornerRadius(dp(r));
        return d;
    }

    private TextView txt(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, 1);
        return t;
    }

    private Button btn(String s, int color) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(Color.WHITE);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setBackground(shape(color, 12));
        return b;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences("truck_stats", MODE_PRIVATE);
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);

        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }
        makeTab();
    }

    private WindowManager.LayoutParams lp(int w, int h, int gravity) {
        return new WindowManager.LayoutParams(
            w, h,
            Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );
    }

    private void makeTab() {
        tab = txt("🚛", 22, Color.WHITE, true);
        ((TextView)tab).setGravity(Gravity.CENTER);
        tab.setBackground(shape(0xEE18A879, 18));

        tabLp = lp(dp(52), dp(58), Gravity.RIGHT);
        tabLp.gravity = Gravity.TOP | Gravity.RIGHT;
        tabLp.y = dp(180);

        wm.addView(tab, tabLp);

        tab.setOnTouchListener(new View.OnTouchListener() {
            float sy;
            int oy;

            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == 0) {
                    sy = e.getRawY();
                    oy = tabLp.y;
                    return true;
                }
                if (e.getAction() == 1) {
                    if (Math.abs(e.getRawY() - sy) < dp(8)) toggle();
                    return true;
                }
                if (e.getAction() == 2) {
                    tabLp.y = Math.max(0, oy + (int)(e.getRawY() - sy));
                    wm.updateViewLayout(tab, tabLp);
                    return true;
                }
                return true;
            }
        });
    }

    private void toggle() {
        if (expanded) {
            hideKeyboard();
            if (panel != null) {
                wm.removeView(panel);
                panel = null;
            }
            expanded = false;
            editing = false;
        } else {
            makePanel();
            expanded = true;
        }
    }

    private void makePanel() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(1);
        root.setPadding(dp(14), dp(14), dp(14), dp(14));
        root.setBackground(shape(0xF21D2733, 18));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(txt("TRUCK HELPER", 15, Color.WHITE, true),
            new LinearLayout.LayoutParams(0, -2, 1));

        Button close = btn("×", 0xFF344354);
        head.addView(close, new LinearLayout.LayoutParams(dp(42), dp(40)));
        close.setOnClickListener(v -> toggle());
        root.addView(head);

        earnings = txt("", 16, 0xFF55D6A2, true);
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, -2);
        ep.topMargin = dp(12);
        root.addView(earnings, ep);

        count = txt("", 12, Color.WHITE, false);
        root.addView(count);

        round = btn("", 0xFF20B989);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(52));
        rp.topMargin = dp(14);
        root.addView(round, rp);

        round.setOnClickListener(v -> {
            int pay = prefs.getInt("pay", 15000);
            long trips = prefs.getLong("trips", 0) + 1;
            long balance = prefs.getLong("balance", 0) + pay;
            long earned = prefs.getLong("shiftEarned", 0) + pay;

            prefs.edit()
                .putLong("trips", trips)
                .putLong("balance", balance)
                .putLong("shiftEarned", earned)
                .apply();

            refreshStats();
            Toast.makeText(this, "Круг учтён: +" + money(pay) + " ₽",
                Toast.LENGTH_SHORT).show();
        });

        Button settings = btn("НАСТРОЙКИ ВЫПЛАТЫ И ЦЕЛИ", 0xFF344354);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, dp(46));
        sp.topMargin = dp(8);
        root.addView(settings, sp);

        settingsBox = new LinearLayout(this);
        settingsBox.setOrientation(1);
        settingsBox.setPadding(0, dp(8), 0, 0);
        settingsBox.setVisibility(View.GONE);

        TextView payLabel = txt("Выплата за круг", 12, Color.WHITE, false);
        settingsBox.addView(payLabel);

        payInput = new EditText(this);
        payInput.setSingleLine(true);
        payInput.setTextColor(Color.WHITE);
        payInput.setHintTextColor(0xFFAAAAAA);
        payInput.setHint("Сумма выплаты");
        payInput.setInputType(2);
        payInput.setText(String.valueOf(prefs.getInt("pay", 15000)));
        payInput.setSelectAllOnFocus(true);
        settingsBox.addView(payInput);

        TextView goalLabel = txt("Цель накоплений", 12, Color.WHITE, false);
        settingsBox.addView(goalLabel);

        goalInput = new EditText(this);
        goalInput.setSingleLine(true);
        goalInput.setTextColor(Color.WHITE);
        goalInput.setHintTextColor(0xFFAAAAAA);
        goalInput.setHint("Целевая сумма");
        goalInput.setInputType(2);
        goalInput.setText(String.valueOf(prefs.getLong("goal", 5000000)));
        goalInput.setSelectAllOnFocus(true);
        settingsBox.addView(goalInput);

        Button save = btn("СОХРАНИТЬ", 0xFF20B989);
        settingsBox.addView(save);

        Button cancel = btn("ОТМЕНА", 0xFF344354);
        settingsBox.addView(cancel);

        root.addView(settingsBox);

        settings.setOnClickListener(v -> {
            if (editing) {
                hideKeyboard();
                settingsBox.setVisibility(View.GONE);
                setPanelFocusable(false);
                editing = false;
            } else {
                editing = true;
                settingsBox.setVisibility(View.VISIBLE);
                setPanelFocusable(true);
                payInput.requestFocus();
            }
        });

        save.setOnClickListener(v -> {
            try {
                int p = Integer.parseInt(payInput.getText().toString().trim());
                long g = Long.parseLong(goalInput.getText().toString().trim());

                if (p < 1 || g < 1) throw new Exception();

                prefs.edit()
                    .putInt("pay", p)
                    .putLong("goal", g)
                    .apply();

                hideKeyboard();
                settingsBox.setVisibility(View.GONE);
                setPanelFocusable(false);
                editing = false;
                refreshStats();

                Toast.makeText(this, "Настройки сохранены!",
                    Toast.LENGTH_SHORT).show();

            } catch (Exception e) {
                Toast.makeText(this, "Введи положительные числа",
                    Toast.LENGTH_SHORT).show();
            }
        });

        cancel.setOnClickListener(v -> {
            hideKeyboard();
            settingsBox.setVisibility(View.GONE);
            setPanelFocusable(false);
            editing = false;
        });

        Button shift = btn("ЗАВЕРШИТЬ СМЕНУ", 0xFF344354);
        LinearLayout.LayoutParams sh = new LinearLayout.LayoutParams(-1, dp(44));
        sh.topMargin = dp(8);
        root.addView(shift, sh);

        shift.setOnClickListener(v -> {
            prefs.edit().putLong("shiftEarned", 0).apply();
            refreshStats();
            Toast.makeText(this,
                "Смена завершена. Общая статистика сохранена.",
                Toast.LENGTH_SHORT).show();
        });

        // КНОПКА СБРОСА СТАТИСТИКИ
        Button reset = btn("СБРОСИТЬ СТАТИСТИКУ", 0xFFB84040);
        LinearLayout.LayoutParams resetParams =
            new LinearLayout.LayoutParams(-1, dp(44));
        resetParams.topMargin = dp(8);
        root.addView(reset, resetParams);

        reset.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                .setTitle("Сброс статистики")
                .setMessage("Ты действительно хочешь обнулить все круги, общий баланс и заработок смены? Это действие нельзя отменить.")
                .setNegativeButton("ОТМЕНА", (dialog, which) -> dialog.dismiss())
                .setPositiveButton("СБРОСИТЬ", (dialog, which) -> {
                    prefs.edit()
                        .putLong("trips", 0)
                        .putLong("balance", 0)
                        .putLong("shiftEarned", 0)
                        .apply();

                    refreshStats();

                    Toast.makeText(this,
                        "Статистика успешно сброшена!",
                        Toast.LENGTH_SHORT).show();
                })
                .show();
        });

        panel = root;
        panelLp = lp(dp(290), -2, Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        panelLp.gravity = Gravity.TOP | Gravity.RIGHT;
        panelLp.y = Math.max(dp(20), tabLp.y - dp(60));
        panelLp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE;

        wm.addView(panel, panelLp);
        refreshStats();
    }

    private void setPanelFocusable(boolean focusable) {
        if (panel == null || panelLp == null) return;

        if (focusable) {
            panelLp.flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        } else {
            panelLp.flags =
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        }

        wm.updateViewLayout(panel, panelLp);
    }

    private void hideKeyboard() {
        try {
            InputMethodManager imm =
                (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null && panel != null) {
                imm.hideSoftInputFromWindow(panel.getWindowToken(), 0);
            }
        } catch (Exception ignored) {}
    }

    private void refreshStats() {
        if (earnings != null) {
            earnings.setText("Заработано: " +
                money(prefs.getLong("shiftEarned", 0)) + " ₽");
        }

        if (count != null) {
            count.setText("Кругов: " +
                prefs.getLong("trips", 0) +
                "   Баланс: " +
                money(prefs.getLong("balance", 0)) + " ₽\n" +
                "Цель: " +
                money(prefs.getLong("goal", 5000000)) + " ₽");
        }

        if (round != null) {
            round.setText("СДЕЛАЛ КРУГ  +" +
                money(prefs.getInt("pay", 15000)) + " ₽");
        }
    }

    private String money(long n) {
        return NumberFormat.getIntegerInstance(new Locale("ru", "RU"))
            .format(n);
    }

    @Override
    public int onStartCommand(Intent i, int f, int id) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        try {
            hideKeyboard();
            if (tab != null) wm.removeView(tab);
            if (panel != null) wm.removeView(panel);
        } catch (Exception ignored) {}
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }
}
