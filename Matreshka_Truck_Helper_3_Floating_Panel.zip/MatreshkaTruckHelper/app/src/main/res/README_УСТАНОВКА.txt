MATRESHKA TRUCK HELPER — фиолетовая неоновая иконка

Эта папка res содержит launcher PNG для пяти плотностей Android.
Скопируй папки mipmap-* в:
app/src/main/res/

Если спросит объединить папки или заменить совпадающие файлы — соглашайся.
Не удаляй остальные ресурсы проекта.

Проверь AndroidManifest.xml: желательно, чтобы у application были:
android:icon="@mipmap/ic_launcher"
android:roundIcon="@mipmap/ic_launcher_round"
Если в манифесте указано другое имя ресурса, его нужно сохранить или переименовать PNG под это имя.
