package com.matreshka.truckhelper;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import android.content.*;
import java.text.NumberFormat;
import java.util.Locale;

public class MainActivity extends Activity {
    private int pay() { return prefs.getInt("pay", 15000); }
    private long goal() { return prefs.getLong("goal", 5000000L); }
    private android.content.SharedPreferences prefs;
    private TextView balanceView, tripsView, rateView, timerView, progressView, statusView;
    private EditText startBalanceInput;
    private Button startButton, finishButton;
    private Handler handler = new Handler();
    private long balance, trips, totalSeconds, startAt;
    private boolean running = false;

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (running) {
                long elapsed = (System.currentTimeMillis() - startAt) / 1000;
                timerView.setText(formatTime(elapsed));
                handler.postDelayed(this, 1000);
            }
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("truck_stats", MODE_PRIVATE);
        balance = prefs.getLong("balance", 0);
        trips = prefs.getLong("trips", 0);
        totalSeconds = prefs.getLong("seconds", 0);
        startAt = prefs.getLong("startAt", 0);
        running = prefs.getBoolean("running", false);
        if (running && startAt > 0) handler.post(ticker);
        buildUi();
        update();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(20), dp(22), dp(20), dp(24));
        root.setBackgroundColor(Color.rgb(16,21,29)); scroll.addView(root); setContentView(scroll);

        TextView title = text("MATRESHKA", 13, Color.rgb(85,214,162), true);
        root.addView(title);
        TextView subtitle = text("TRUCK HELPER", 27, Color.WHITE, true);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2); sp.topMargin = dp(3); root.addView(subtitle, sp);
        TextView desc = text("Твой учёт рейсов и заработка", 14, 0xFF9AA7B7, false);
        root.addView(desc);

        LinearLayout balanceCard = card(root);
        balanceCard.addView(text("ТЕКУЩИЙ БАЛАНС", 12, 0xFF9AA7B7, true));
        balanceView = text("0 ₽", 32, Color.WHITE, true); LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1,-2); bp.topMargin=dp(7); balanceCard.addView(balanceView,bp);
        progressView = text("До цели 5 000 000 ₽ осталось 5 000 000 ₽", 13, 0xFF55D6A2, false);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1,-2); pp.topMargin=dp(8); balanceCard.addView(progressView,pp);
        ProgressBar bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100); bar.setId(1001); bar.setProgressTintList(android.content.res.ColorStateList.valueOf(0xFF55D6A2));
        LinearLayout.LayoutParams barp = new LinearLayout.LayoutParams(-1,dp(7)); barp.topMargin=dp(12); balanceCard.addView(bar,barp);

        LinearLayout stats = new LinearLayout(this); stats.setOrientation(0);
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(-1,-2); stp.topMargin=dp(14); root.addView(stats,stp);
        LinearLayout c1 = smallCard(); LinearLayout c2 = smallCard();
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0,-2,1); cp.rightMargin=dp(6); stats.addView(c1,cp);
        LinearLayout.LayoutParams cp2 = new LinearLayout.LayoutParams(0,-2,1); cp2.leftMargin=dp(6); stats.addView(c2,cp2);
        c1.addView(text("РЕЙСЫ",11,0xFF9AA7B7,true)); tripsView=text("0",24,Color.WHITE,true); c1.addView(tripsView);
        c2.addView(text("СРЕДНИЙ ДОХОД / Ч",11,0xFF9AA7B7,true)); rateView=text("0 ₽",24,Color.WHITE,true); c2.addView(rateView);

        LinearLayout timerCard = card(root);
        timerCard.addView(text("ТЕКУЩИЙ РЕЙС",12,0xFF9AA7B7,true));
        timerView=text("00:00",30,Color.WHITE,true); LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2); tp.topMargin=dp(5); timerCard.addView(timerView,tp);
        statusView=text(running ? "Рейс уже идёт" : "Ожидание начала рейса",13,0xFF9AA7B7,false); timerCard.addView(statusView);

        startButton = button("НАЧАТЬ РЕЙС", 0xFF55D6A2, 0xFF10151D);
        LinearLayout.LayoutParams b1=new LinearLayout.LayoutParams(-1,dp(54)); b1.topMargin=dp(16); root.addView(startButton,b1);
        startButton.setOnClickListener(v -> startTrip());
        finishButton = button("ЗАВЕРШИТЬ РЕЙС  +15 000 ₽", 0xFF263342, Color.WHITE);
        LinearLayout.LayoutParams b2=new LinearLayout.LayoutParams(-1,dp(54)); b2.topMargin=dp(10); root.addView(finishButton,b2);
        finishButton.setOnClickListener(v -> finishTrip());

        TextView pay = text("Учёт рассчитан на твой обычный рейс: 15 000 ₽. Если выплата изменилась, её можно поменять в настройках.",12,0xFF9AA7B7,false);
        LinearLayout.LayoutParams payp=new LinearLayout.LayoutParams(-1,-2); payp.topMargin=dp(15); root.addView(pay,payp);

        Button settings=button("НАСТРОИТЬ СТАРТОВЫЙ БАЛАНС",0xFF1D2733,Color.WHITE);
        LinearLayout.LayoutParams setp=new LinearLayout.LayoutParams(-1,dp(48)); setp.topMargin=dp(14); root.addView(settings,setp);
        settings.setOnClickListener(v -> showSettings());
        Button rates=button("НАСТРОИТЬ ВЫПЛАТУ И ЦЕЛЬ",0xFF1D2733,Color.WHITE);
        LinearLayout.LayoutParams ratp=new LinearLayout.LayoutParams(-1,dp(48)); ratp.topMargin=dp(8); root.addView(rates,ratp);
        rates.setOnClickListener(v -> showPayGoalSettings());
        Button overlay=button("ВКЛЮЧИТЬ ПАНЕЛЬ ПОВЕРХ ИГРЫ",0xFF263342,Color.WHITE);
        LinearLayout.LayoutParams ovp=new LinearLayout.LayoutParams(-1,dp(50)); ovp.topMargin=dp(10); root.addView(overlay,ovp);
        overlay.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= 23 && !android.provider.Settings.canDrawOverlays(this)) {
                Intent i=new Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:"+getPackageName())); startActivity(i);
                Toast.makeText(this,"Разреши отображение поверх других приложений, затем вернись сюда",Toast.LENGTH_LONG).show();
            } else { startService(new Intent(this, FloatingPanelService.class)); Toast.makeText(this,"Панель включена — переходи в игру",Toast.LENGTH_SHORT).show(); }
        });
        Button reset=button("СБРОСИТЬ СТАТИСТИКУ",0xFF1D2733,0xFFFF8B8B);
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(44)); rp.topMargin=dp(8); root.addView(reset,rp);
        reset.setOnClickListener(v -> confirmReset());
    }

    private LinearLayout card(LinearLayout parent) {
        LinearLayout box=new LinearLayout(this); box.setOrientation(1); box.setPadding(dp(16),dp(15),dp(16),dp(15)); box.setBackground(bg(0xFF1D2733,18));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.topMargin=dp(18); parent.addView(box,p); return box;
    }
    private LinearLayout smallCard() {
        LinearLayout box=new LinearLayout(this); box.setOrientation(1); box.setPadding(dp(14),dp(14),dp(14),dp(14)); box.setBackground(bg(0xFF1D2733,16)); return box;
    }
    private Button button(String label,int background,int foreground) {
        Button b=new Button(this); b.setText(label); b.setTextSize(13); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setTextColor(foreground);
        b.setAllCaps(false); b.setBackground(bg(background,15)); return b;
    }
    private void startTrip() {
        if (running) return;
        running=true; startAt=System.currentTimeMillis(); prefs.edit().putBoolean("running",true).putLong("startAt",startAt).apply();
        handler.post(ticker); update();
    }
    private void finishTrip() {
        if (!running) { Toast.makeText(this,"Сначала начни рейс",Toast.LENGTH_SHORT).show(); return; }
        long elapsed=Math.max(1,(System.currentTimeMillis()-startAt)/1000);
        totalSeconds+=elapsed; trips++; balance+=pay(); running=false; startAt=0;
        prefs.edit().putLong("balance",balance).putLong("trips",trips).putLong("seconds",totalSeconds).putBoolean("running",false).putLong("startAt",0).apply();
        handler.removeCallbacks(ticker); update();
        new AlertDialog.Builder(this).setTitle("Рейс завершён").setMessage("+"+money(pay())+" ₽\nВремя: "+formatTime(elapsed)).setPositiveButton("Отлично",null).show();
    }
    private void update() {
        balanceView.setText(money(balance)+" ₽"); tripsView.setText(String.valueOf(trips));
        long remain=Math.max(0,goal()-balance); progressView.setText("До цели осталось "+money(remain)+" ₽");
        long all=totalSeconds+(running?Math.max(0,(System.currentTimeMillis()-startAt)/1000):0);
        long earned=trips*(long)pay();
        long hourly=all>0?(long)(earned*3600.0/all):0;
        rateView.setText(money(hourly)+" ₽");
        ProgressBar bar=findViewById(1001); if(bar!=null) bar.setProgress((int)Math.min(100,balance*100/Math.max(1,goal())));
        statusView.setText(running?"Рейс уже идёт":"Ожидание начала рейса");
        startButton.setEnabled(!running); startButton.setAlpha(running?0.45f:1f);
        finishButton.setEnabled(running); finishButton.setAlpha(running?1f:0.45f);
    }
    private void showSettings() {
        EditText input=new EditText(this); input.setInputType(2); input.setHint("Например: 150000");
        input.setText(String.valueOf(balance));
        new AlertDialog.Builder(this).setTitle("Стартовый баланс").setMessage("Укажи текущий баланс в игре, чтобы приложение считало прогресс к цели.").setView(input)
        .setNegativeButton("Отмена",null).setPositiveButton("Сохранить",(d,w)->{
            try { balance=Math.max(0,Long.parseLong(input.getText().toString().trim())); prefs.edit().putLong("balance",balance).apply(); update(); }
            catch(Exception e){Toast.makeText(this,"Введи число без пробелов",Toast.LENGTH_SHORT).show();}
        }).show();
    }

    private void showPayGoalSettings() {
        LinearLayout box=new LinearLayout(this); box.setOrientation(1); box.setPadding(dp(8),dp(4),dp(8),dp(4));
        EditText payInput=new EditText(this); payInput.setInputType(2); payInput.setHint("Выплата за круг"); payInput.setText(String.valueOf(pay())); box.addView(payInput);
        EditText goalInput=new EditText(this); goalInput.setInputType(2); goalInput.setHint("Цель накоплений"); goalInput.setText(String.valueOf(goal())); box.addView(goalInput);
        new AlertDialog.Builder(this).setTitle("Настройки заработка").setView(box).setNegativeButton("Отмена",null).setPositiveButton("Сохранить",(d,w)->{
            try { int p=Integer.parseInt(payInput.getText().toString().trim()); long g=Long.parseLong(goalInput.getText().toString().trim()); if(p<=0||g<=0) throw new Exception(); prefs.edit().putInt("pay",p).putLong("goal",g).apply(); update(); }
            catch(Exception e){Toast.makeText(this,"Введи положительные числа",Toast.LENGTH_SHORT).show();}
        }).show();
    }

    private void confirmReset() {
        new AlertDialog.Builder(this).setTitle("Сбросить всё?").setMessage("Баланс, рейсы и время будут обнулены.")
        .setNegativeButton("Отмена",null).setPositiveButton("Сбросить",(d,w)->{
            running=false; startAt=0; balance=0; trips=0; totalSeconds=0; handler.removeCallbacks(ticker);
            prefs.edit().clear().apply(); update();
        }).show();
    }
    private String money(long n) { return NumberFormat.getIntegerInstance(new Locale("ru","RU")).format(n); }
    private String formatTime(long sec) { return String.format(Locale.US,"%02d:%02d:%02d",sec/3600,(sec%3600)/60,sec%60); }
    @Override protected void onDestroy() { super.onDestroy(); }
}
